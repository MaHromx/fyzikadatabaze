import { useState, useRef, useMemo, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useToast } from "@/hooks/use-toast";
import { Upload, FileText, Film, Download, Loader2, CloudUpload, Trash2, Search, X } from "lucide-react";
import type { UploadedFile } from "@shared/schema";
import { generateVideoThumbnail, isThumbnailSupported } from "@/lib/thumbnail";

/**
 * Home Page Component
 * Main page for file upload and management
 */
export default function Home() {
  const [isDragging, setIsDragging] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadingFileName, setUploadingFileName] = useState<string | null>(null);
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [fileToDelete, setFileToDelete] = useState<UploadedFile | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [fileTypeFilter, setFileTypeFilter] = useState<"all" | "pdf" | "video">("all");
  // Store thumbnails as a map of file ID to data URL
  const [thumbnails, setThumbnails] = useState<Record<string, string>>({});
  const resetTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const { toast } = useToast();

  // Fetch all uploaded files
  const { data: files = [], isLoading } = useQuery<UploadedFile[]>({
    queryKey: ["/api/files"],
  });

  // Generate thumbnails for video files when files list changes
  useEffect(() => {
    // Only generate thumbnails for files we don't already have
    const generateMissingThumbnails = async () => {
      for (const file of files) {
        // Skip if we already have a thumbnail for this file
        if (thumbnails[file.id]) continue;
        
        // Only generate thumbnails for supported file types (videos)
        if (isThumbnailSupported(file.mimetype)) {
          try {
            const videoUrl = `/api/files/${file.id}/download`;
            const thumbnailData = await generateVideoThumbnail(videoUrl, 1);
            
            // Update thumbnails state with the new thumbnail
            setThumbnails(prev => ({
              ...prev,
              [file.id]: thumbnailData
            }));
          } catch (error) {
            console.error(`Failed to generate thumbnail for ${file.originalName}:`, error);
            // Don't show toast for thumbnail generation errors
            // as they're not critical to functionality
          }
        }
      }
    };

    generateMissingThumbnails();
  }, [files, thumbnails]);

  // Upload file with progress tracking using XMLHttpRequest
  const uploadFile = (file: File) => {
    return new Promise<UploadedFile>((resolve, reject) => {
      const formData = new FormData();
      formData.append("file", file);

      const xhr = new XMLHttpRequest();

      // Track upload progress
      xhr.upload.addEventListener("progress", (event) => {
        if (event.lengthComputable) {
          const percentComplete = Math.round((event.loaded / event.total) * 100);
          setUploadProgress(percentComplete);
        }
      });

      // Handle successful upload
      xhr.addEventListener("load", () => {
        if (xhr.status >= 200 && xhr.status < 300) {
          try {
            const response = JSON.parse(xhr.responseText);
            resolve(response);
          } catch (error) {
            reject(new Error("Failed to parse server response"));
          }
        } else {
          try {
            const error = JSON.parse(xhr.responseText);
            reject(new Error(error.message || "Upload failed"));
          } catch {
            reject(new Error(`Upload failed with status ${xhr.status}`));
          }
        }
      });

      // Handle errors
      xhr.addEventListener("error", () => {
        reject(new Error("Network error occurred during upload"));
      });

      xhr.addEventListener("abort", () => {
        reject(new Error("Upload was cancelled"));
      });

      // Send the request
      xhr.open("POST", "/api/upload");
      xhr.send(formData);
    });
  };

  // Upload file mutation
  const uploadMutation = useMutation({
    mutationFn: async (file: File) => {
      // Cancel any pending reset timeout from previous upload
      if (resetTimeoutRef.current) {
        clearTimeout(resetTimeoutRef.current);
        resetTimeoutRef.current = null;
      }
      
      setUploadingFileName(file.name);
      setUploadProgress(0);
      return uploadFile(file);
    },
    onSuccess: () => {
      // Set progress to 100% to ensure completion is visible
      setUploadProgress(100);
      queryClient.invalidateQueries({ queryKey: ["/api/files"] });
      toast({
        title: "Success!",
        description: "File uploaded successfully",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Upload failed",
        description: error.message,
        variant: "destructive",
      });
    },
    onSettled: () => {
      // Reset progress after mutation completes (success or error)
      // Use a small delay to show 100% completion briefly
      resetTimeoutRef.current = setTimeout(() => {
        setUploadProgress(0);
        setUploadingFileName(null);
        resetTimeoutRef.current = null;
      }, 500);
    },
  });

  // Delete file mutation
  const deleteMutation = useMutation({
    mutationFn: async (fileId: string) => {
      return apiRequest("DELETE", `/api/files/${fileId}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/files"] });
      toast({
        title: "File deleted",
        description: "The file has been removed successfully",
      });
      setDeleteDialogOpen(false);
      setFileToDelete(null);
    },
    onError: (error: Error) => {
      toast({
        title: "Delete failed",
        description: error.message,
        variant: "destructive",
      });
    },
  });

  // Handle delete button click
  const handleDeleteClick = (file: UploadedFile) => {
    setFileToDelete(file);
    setDeleteDialogOpen(true);
  };

  // Confirm deletion
  const confirmDelete = () => {
    if (fileToDelete) {
      deleteMutation.mutate(fileToDelete.id);
    }
  };

  // File validation constants
  const MAX_FILE_SIZE = 100 * 1024 * 1024; // 100MB in bytes
  const ALLOWED_TYPES = {
    "application/pdf": ".pdf",
    "video/mp4": ".mp4",
    "video/mpeg": ".mpeg",
    "video/quicktime": ".mov",
    "video/x-msvideo": ".avi",
    "video/x-matroska": ".mkv",
    "video/webm": ".webm",
  };

  // Validate file before upload
  const validateFile = (file: File): { valid: boolean; error?: string } => {
    // Check file size
    if (file.size > MAX_FILE_SIZE) {
      return {
        valid: false,
        error: `File size exceeds ${formatFileSize(MAX_FILE_SIZE)} limit. Your file is ${formatFileSize(file.size)}.`,
      };
    }

    // Check file type
    if (!Object.keys(ALLOWED_TYPES).includes(file.type)) {
      return {
        valid: false,
        error: `File type not supported. Please upload PDF or video files only.`,
      };
    }

    return { valid: true };
  };

  // Handle file selection
  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const validation = validateFile(file);
      if (!validation.valid) {
        toast({
          title: "Invalid file",
          description: validation.error,
          variant: "destructive",
        });
      } else {
        uploadMutation.mutate(file);
      }
    }
    // Reset input so the same file can be uploaded again
    e.target.value = "";
  };

  // Handle drag and drop
  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(true);
  };

  const handleDragLeave = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);

    const file = e.dataTransfer.files?.[0];
    if (file) {
      const validation = validateFile(file);
      if (!validation.valid) {
        toast({
          title: "Invalid file",
          description: validation.error,
          variant: "destructive",
        });
      } else {
        uploadMutation.mutate(file);
      }
    }
  };

  // Format file size for display
  const formatFileSize = (bytes: number): string => {
    if (bytes === 0) return "0 Bytes";
    const k = 1024;
    const sizes = ["Bytes", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return Math.round(bytes / Math.pow(k, i) * 100) / 100 + " " + sizes[i];
  };

  // Get icon for file type
  const getFileIcon = (mimetype: string) => {
    if (mimetype.startsWith("video/")) {
      return <Film className="w-5 h-5 text-muted-foreground" />;
    }
    if (mimetype === "application/pdf") {
      return <FileText className="w-5 h-5 text-muted-foreground" />;
    }
    return <FileText className="w-5 h-5 text-muted-foreground" />;
  };

  // Format upload date
  const formatDate = (dateString: string): string => {
    const date = new Date(dateString);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return "Just now";
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    if (days < 7) return `${days}d ago`;
    
    return date.toLocaleDateString();
  };

  // Filter and search files
  const filteredFiles = useMemo(() => {
    return files.filter((file) => {
      // Filter by file type
      if (fileTypeFilter === "pdf" && !file.mimetype.includes("pdf")) {
        return false;
      }
      if (fileTypeFilter === "video" && !file.mimetype.startsWith("video/")) {
        return false;
      }

      // Filter by search query
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        return file.originalName.toLowerCase().includes(query);
      }

      return true;
    });
  }, [files, fileTypeFilter, searchQuery]);

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="container flex h-14 items-center">
          <div className="flex items-center gap-2">
            <CloudUpload className="w-5 h-5 text-primary" />
            <h1 className="text-lg font-semibold" data-testid="text-app-title">File Upload Manager</h1>
          </div>
          {files.length > 0 && (
            <div className="ml-auto">
              <span className="text-sm text-muted-foreground" data-testid="text-file-count">
                {files.length} {files.length === 1 ? "file" : "files"}
              </span>
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="container max-w-4xl mx-auto px-4 py-8">
        {/* Upload Section */}
        <section className="mb-8">
          <h2 className="text-2xl font-semibold mb-4">Upload Files</h2>
          
          <Card
            className={`relative transition-all duration-200 ${
              isDragging
                ? "border-primary bg-primary/5 shadow-md"
                : "border-dashed hover:border-primary/50 hover:bg-accent/50"
            }`}
            onDragOver={handleDragOver}
            onDragLeave={handleDragLeave}
            onDrop={handleDrop}
            data-testid="card-upload-zone"
          >
            <div className="min-h-64 flex flex-col items-center justify-center p-6 text-center">
              {uploadMutation.isPending ? (
                <>
                  <Upload className="w-16 h-16 text-primary mb-4" />
                  <p className="text-lg font-medium mb-2">Uploading</p>
                  {uploadingFileName && (
                    <p className="text-sm text-muted-foreground mb-4 font-mono max-w-md truncate">
                      {uploadingFileName}
                    </p>
                  )}
                  <div className="w-full max-w-md space-y-2">
                    <Progress value={uploadProgress} className="h-2" data-testid="progress-upload" />
                    <p className="text-sm font-medium text-primary" data-testid="text-upload-progress">
                      {uploadProgress}%
                    </p>
                  </div>
                </>
              ) : (
                <>
                  <Upload className="w-16 h-16 text-muted-foreground mb-4" />
                  <p className="text-lg font-medium mb-2">
                    Drag and drop files here or click to browse
                  </p>
                  <p className="text-sm text-muted-foreground mb-2">
                    Supports PDF and video files
                  </p>
                  <p className="text-xs text-muted-foreground mb-6" data-testid="text-file-limit">
                    Maximum file size: {formatFileSize(MAX_FILE_SIZE)}
                  </p>
                  <label htmlFor="file-input">
                    <Button
                      variant="default"
                      size="lg"
                      className="cursor-pointer"
                      asChild
                      data-testid="button-browse-files"
                    >
                      <span>
                        <Upload className="w-4 h-4 mr-2" />
                        Browse Files
                      </span>
                    </Button>
                  </label>
                  <input
                    id="file-input"
                    type="file"
                    className="hidden"
                    accept=".pdf,video/*"
                    onChange={handleFileSelect}
                    data-testid="input-file-upload"
                  />
                </>
              )}
            </div>
          </Card>
        </section>

        {/* Files List Section */}
        <section>
          <div className="flex flex-col gap-4 mb-4">
            <h2 className="text-2xl font-semibold">Uploaded Files</h2>
            
            {/* Search and Filter Controls */}
            {files.length > 0 && (
              <div className="flex flex-col sm:flex-row gap-3">
                <div className="relative flex-1">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    type="text"
                    placeholder="Search files by name..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-9 pr-9"
                    data-testid="input-search-files"
                  />
                  {searchQuery && (
                    <button
                      onClick={() => setSearchQuery("")}
                      className="absolute right-3 top-1/2 transform -translate-y-1/2"
                      data-testid="button-clear-search"
                    >
                      <X className="w-4 h-4 text-muted-foreground hover:text-foreground" />
                    </button>
                  )}
                </div>
                <div className="flex gap-2">
                  <Button
                    variant={fileTypeFilter === "all" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setFileTypeFilter("all")}
                    data-testid="button-filter-all"
                  >
                    All
                  </Button>
                  <Button
                    variant={fileTypeFilter === "pdf" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setFileTypeFilter("pdf")}
                    data-testid="button-filter-pdf"
                  >
                    <FileText className="w-4 h-4 mr-2" />
                    PDF
                  </Button>
                  <Button
                    variant={fileTypeFilter === "video" ? "default" : "outline"}
                    size="sm"
                    onClick={() => setFileTypeFilter("video")}
                    data-testid="button-filter-video"
                  >
                    <Film className="w-4 h-4 mr-2" />
                    Video
                  </Button>
                </div>
              </div>
            )}
          </div>

          {isLoading ? (
            <Card className="p-12">
              <div className="flex flex-col items-center justify-center text-center">
                <Loader2 className="w-8 h-8 text-primary animate-spin mb-4" />
                <p className="text-muted-foreground">Loading files...</p>
              </div>
            </Card>
          ) : files.length === 0 ? (
            <Card className="p-12" data-testid="card-empty-state">
              <div className="flex flex-col items-center justify-center text-center">
                <FileText className="w-16 h-16 text-muted-foreground mb-4" />
                <p className="text-lg font-medium mb-2">No files uploaded yet</p>
                <p className="text-sm text-muted-foreground">
                  Upload your first file using the form above
                </p>
              </div>
            </Card>
          ) : filteredFiles.length === 0 ? (
            <Card className="p-12" data-testid="card-no-results">
              <div className="flex flex-col items-center justify-center text-center">
                <Search className="w-16 h-16 text-muted-foreground mb-4" />
                <p className="text-lg font-medium mb-2">No files found</p>
                <p className="text-sm text-muted-foreground">
                  Try adjusting your search or filters
                </p>
                {(searchQuery || fileTypeFilter !== "all") && (
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setSearchQuery("");
                      setFileTypeFilter("all");
                    }}
                    className="mt-4"
                    data-testid="button-clear-filters"
                  >
                    Clear filters
                  </Button>
                )}
              </div>
            </Card>
          ) : (
            <div className="space-y-2">
              {filteredFiles.map((file) => (
                <Card
                  key={file.id}
                  className="p-4 hover:shadow-md transition-shadow"
                  data-testid={`card-file-${file.id}`}
                >
                  <div className="flex items-center gap-4">
                    {/* File Icon or Thumbnail */}
                    <div className="flex-shrink-0">
                      {thumbnails[file.id] ? (
                        <div className="relative w-16 h-16 rounded-md overflow-hidden border border-border bg-muted">
                          <img
                            src={thumbnails[file.id]}
                            alt={`Thumbnail for ${file.originalName}`}
                            className="w-full h-full object-cover"
                            data-testid={`img-thumbnail-${file.id}`}
                          />
                        </div>
                      ) : (
                        <div className="w-16 h-16 rounded-md border border-border bg-muted flex items-center justify-center">
                          {getFileIcon(file.mimetype)}
                        </div>
                      )}
                    </div>

                    {/* File Info */}
                    <div className="flex-1 min-w-0">
                      <p
                        className="font-mono text-sm font-medium truncate"
                        title={file.originalName}
                        data-testid={`text-filename-${file.id}`}
                      >
                        {file.originalName}
                      </p>
                      <div className="flex items-center gap-3 mt-1">
                        <span className="text-xs text-muted-foreground" data-testid={`text-filesize-${file.id}`}>
                          {formatFileSize(file.size)}
                        </span>
                        <span className="text-xs text-muted-foreground">•</span>
                        <span className="text-xs text-muted-foreground" data-testid={`text-filedate-${file.id}`}>
                          {formatDate(file.uploadedAt)}
                        </span>
                      </div>
                    </div>

                    {/* Actions */}
                    <div className="flex-shrink-0 flex items-center gap-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        asChild
                        data-testid={`button-download-${file.id}`}
                      >
                        <a
                          href={`/api/files/${file.id}/download`}
                          target="_blank"
                          rel="noopener noreferrer"
                        >
                          <Download className="w-4 h-4 mr-2" />
                          Download
                        </a>
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeleteClick(file)}
                        data-testid={`button-delete-${file.id}`}
                      >
                        <Trash2 className="w-4 h-4 mr-2" />
                        Delete
                      </Button>
                    </div>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </section>
      </main>

      {/* Footer */}
      <footer className="mt-16 py-6 border-t">
        <div className="container max-w-4xl mx-auto px-4 text-center">
          <p className="text-sm text-muted-foreground">
            File Upload Manager - Upload and manage your files securely
          </p>
        </div>
      </footer>

      {/* Delete Confirmation Dialog */}
      <AlertDialog open={deleteDialogOpen} onOpenChange={setDeleteDialogOpen}>
        <AlertDialogContent data-testid="dialog-delete-confirm">
          <AlertDialogHeader>
            <AlertDialogTitle>Delete File?</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete "{fileToDelete?.originalName}"? This action cannot be
              undone and the file will be permanently removed from the server.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel data-testid="button-cancel-delete">Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={confirmDelete}
              disabled={deleteMutation.isPending}
              data-testid="button-confirm-delete"
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              {deleteMutation.isPending ? "Deleting..." : "Delete"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}
