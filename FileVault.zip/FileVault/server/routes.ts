import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import multer from "multer";
import path from "path";
import fs from "fs";
import { fileSchema } from "@shared/schema";

/**
 * Configure Multer Storage
 * Multer handles file uploads and stores them in the "uploads" folder
 * Files are renamed with timestamp to prevent naming conflicts
 */
const uploadDir = path.join(process.cwd(), "uploads");

// Create uploads directory if it doesn't exist
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Configure Multer storage settings
const multerStorage = multer.diskStorage({
  // Set destination folder for uploaded files
  destination: function (req, file, cb) {
    cb(null, uploadDir);
  },
  // Generate unique filename with timestamp
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
    cb(null, uniqueSuffix + "-" + file.originalname);
  },
});

// Initialize Multer with storage configuration
const upload = multer({
  storage: multerStorage,
  limits: {
    fileSize: 100 * 1024 * 1024, // 100MB file size limit
  },
  fileFilter: (req, file, cb) => {
    // Accept only PDF and video files
    const allowedMimeTypes = [
      "application/pdf",
      "video/mp4",
      "video/mpeg",
      "video/quicktime",
      "video/x-msvideo",
      "video/x-matroska",
      "video/webm",
    ];
    
    if (allowedMimeTypes.includes(file.mimetype)) {
      cb(null, true);
    } else {
      cb(new Error("Only PDF and video files are allowed"));
    }
  },
});

/**
 * Register API Routes
 * Sets up all endpoints for file upload, listing, and download
 */
export async function registerRoutes(app: Express): Promise<Server> {
  /**
   * POST /api/upload
   * Upload a new file
   * Uses Multer middleware to handle multipart/form-data
   */
  app.post("/api/upload", upload.single("file"), async (req, res) => {
    try {
      // Check if file was uploaded
      if (!req.file) {
        return res.status(400).json({ message: "No file uploaded" });
      }

      // Save file metadata to storage
      const fileMetadata = await storage.createFile({
        filename: req.file.filename,
        originalName: req.file.originalname,
        mimetype: req.file.mimetype,
        size: req.file.size,
      });

      // Return uploaded file information
      res.status(201).json(fileMetadata);
    } catch (error) {
      console.error("Upload error:", error);
      res.status(500).json({
        message: error instanceof Error ? error.message : "Failed to upload file",
      });
    }
  });

  /**
   * GET /api/files
   * Retrieve list of all uploaded files
   * Returns file metadata (not the actual files)
   */
  app.get("/api/files", async (req, res) => {
    try {
      const files = await storage.getAllFiles();
      res.json(files);
    } catch (error) {
      console.error("Error fetching files:", error);
      res.status(500).json({ message: "Failed to fetch files" });
    }
  });

  /**
   * GET /api/files/:id/download
   * Download or view a specific file
   * Serves the actual file content from the uploads folder
   */
  app.get("/api/files/:id/download", async (req, res) => {
    try {
      const { id } = req.params;
      
      // Get file metadata from storage
      const file = await storage.getFile(id);
      
      if (!file) {
        return res.status(404).json({ message: "File not found" });
      }

      // Construct file path
      const filePath = path.join(uploadDir, file.filename);

      // Check if file exists on disk
      if (!fs.existsSync(filePath)) {
        return res.status(404).json({ message: "File not found on server" });
      }

      // Set headers for file download
      res.setHeader("Content-Type", file.mimetype);
      res.setHeader(
        "Content-Disposition",
        `inline; filename="${file.originalName}"`
      );

      // Send file to client
      res.sendFile(filePath);
    } catch (error) {
      console.error("Download error:", error);
      res.status(500).json({ message: "Failed to download file" });
    }
  });

  /**
   * DELETE /api/files/:id
   * Delete a file and its metadata
   * Removes both the file from disk and metadata from storage
   */
  app.delete("/api/files/:id", async (req, res) => {
    try {
      const { id } = req.params;

      // Get file metadata from storage
      const file = await storage.getFile(id);

      if (!file) {
        return res.status(404).json({ message: "File not found" });
      }

      // Construct file path
      const filePath = path.join(uploadDir, file.filename);

      // Delete file from disk if it exists
      if (fs.existsSync(filePath)) {
        fs.unlinkSync(filePath);
      }

      // Delete metadata from storage
      const deleted = await storage.deleteFile(id);

      if (deleted) {
        res.json({ message: "File deleted successfully" });
      } else {
        res.status(500).json({ message: "Failed to delete file metadata" });
      }
    } catch (error) {
      console.error("Delete error:", error);
      res.status(500).json({ message: "Failed to delete file" });
    }
  });

  // Create HTTP server
  const httpServer = createServer(app);

  return httpServer;
}
