import { type UploadedFile, type InsertFile } from "@shared/schema";
import { randomUUID } from "crypto";

/**
 * Storage Interface
 * Defines CRUD operations for file metadata
 */
export interface IStorage {
  // File operations
  getAllFiles(): Promise<UploadedFile[]>;
  getFile(id: string): Promise<UploadedFile | undefined>;
  getFileByFilename(filename: string): Promise<UploadedFile | undefined>;
  createFile(file: InsertFile): Promise<UploadedFile>;
  deleteFile(id: string): Promise<boolean>;
}

/**
 * In-Memory Storage Implementation
 * Stores file metadata in memory (files themselves are stored on disk)
 */
export class MemStorage implements IStorage {
  private files: Map<string, UploadedFile>;

  constructor() {
    this.files = new Map();
  }

  async getAllFiles(): Promise<UploadedFile[]> {
    // Return files sorted by upload date (newest first)
    return Array.from(this.files.values()).sort(
      (a, b) => new Date(b.uploadedAt).getTime() - new Date(a.uploadedAt).getTime()
    );
  }

  async getFile(id: string): Promise<UploadedFile | undefined> {
    return this.files.get(id);
  }

  async getFileByFilename(filename: string): Promise<UploadedFile | undefined> {
    return Array.from(this.files.values()).find(
      (file) => file.filename === filename
    );
  }

  async createFile(insertFile: InsertFile): Promise<UploadedFile> {
    const id = randomUUID();
    const file: UploadedFile = {
      ...insertFile,
      id,
      uploadedAt: new Date().toISOString(),
    };
    this.files.set(id, file);
    return file;
  }

  async deleteFile(id: string): Promise<boolean> {
    return this.files.delete(id);
  }
}

export const storage = new MemStorage();
