import { z } from "zod";

/**
 * File Schema
 * Represents an uploaded file with metadata
 */
export const fileSchema = z.object({
  id: z.string(),
  filename: z.string(),
  originalName: z.string(),
  mimetype: z.string(),
  size: z.number(),
  uploadedAt: z.string(),
});

export type UploadedFile = z.infer<typeof fileSchema>;

// Insert schema for file uploads (server will generate id and uploadedAt)
export const insertFileSchema = fileSchema.pick({
  filename: true,
  originalName: true,
  mimetype: true,
  size: true,
});

export type InsertFile = z.infer<typeof insertFileSchema>;
